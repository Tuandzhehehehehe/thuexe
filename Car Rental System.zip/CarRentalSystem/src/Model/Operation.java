package Model;

import java.util.Scanner;

public interface Operation {
	
	public void operation(Database database, Scanner s, User user);

}
